package com.securevault.pro.presentation.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Rendering grammars the component library draws with. Every shipped theme picks
 * one, so the same card, button or icon tile composes differently per theme.
 */
enum class ThemeDesign(
    val label: String,
    val tagline: String
) {
    GENERATIVE("Generative UI", "Adaptive surfaces that shift with context"),
    AGENTIC("Agentic UX", "Intent-first flow, calm conversational surfaces"),
    LIQUID_GLASS("Liquid Glass", "Refractive frosted panes and soft blur"),
    BENTO("Bento Grid 2.0", "Modular tiles on an auto-resizing grid"),
    NEO_SKEUOMORPHIC("Neo-Skeuomorphism", "Tactile matte embossing and bevels"),
    NEO_BRUTALIST("Neo-Brutalism", "Hard outlines, sharp corners, vivid blocks"),
    CLAYMORPHISM("Claymorphism", "Squishy 3D soft-touch forms"),
    CYBERPUNK("Cyberpunk Glow", "Neon mesh gradients, nocturnal highlights"),
    NEUTRAL("Material You", "Plain tonal surfaces, no brand styling")
}

enum class VaultBackdrop {
    PULSE_MESH,
    AURORA_MESH,
    NEON_MESH,
    CALM,
    FLAT_GRID,
    HARD_GRID,
    SOFT_CLAY,
    TEXTURED
}

enum class VaultLayout {
    /** Four equal columns, every cell the same plate. The reference board. */
    CLASSIC,

    /** Four columns, one double-width lead, a full-width closing bar. */
    BENTO,

    /** Full-width intent rails over a quiet grid of bare icons. */
    AGENTIC,

    /** Two wide columns, the first two modules promoted. */
    ADAPTIVE,

    /** Three columns of thick clay plates. */
    GENERATIVE,

    /** Three columns, a double-width cell beside a single, repeated. */
    MOSAIC,

    /** Two columns of full-width rails: label and hint inline, no plate above. */
    LEDGER,

    /** Two columns of large feature cards, icon beside text. */
    DUO,

    /** Five tight columns of bare icons — the smallest cells the board ships. */
    COMPACT,

    /** Six columns, two rows: the densest board, for big screens. */
    DENSE,

    /** Three columns led by one full-width cell, the rest equal plates. */
    COLUMN,

    /** Two columns alternating a feature card with a plain plate. */
    SPLIT,

    /** Three columns alternating a plate with a double-width feature, mirrored. */
    GALLERY,

    /** Four columns led by a full-width rail, then double-width feature pairs. */
    STRIP,

    /** Four columns of double-width feature cells: two per row. */
    TRIAD
}

/** The Material icon language a theme draws its glyphs in. */
enum class IconStyle {
    ROUNDED,
    OUTLINED,
    FILLED,
    SHARP
}

/** How the bottom dock is built: silhouette, float, frosting. */
enum class DockStyle {
    /** Edge-to-edge minimal bar with a hairline top rule. */
    MINIMAL_BAR,
    /** Rounded bar lifted off the sides — the HyperOS/ColorOS shell. */
    SOFT_FLOATING,
    /** Translucent frosted capsule, iOS-style, with a strong blur pane. */
    PILL_FROSTED,
    /** Tall wide panel with roomy labels — One UI comfort targeting. */
    COMFORT_PANEL,
    /** Square-cut flat plate fused to the bottom edge — XOS/EMUI. */
    FLAT_PLATE
}

/** How the screen header is set: alignment, weight, breathing room. */
enum class HeaderStyle {
    /** Compact left-aligned title over a subtitle (MIUI/ColorOS). */
    INLINE_BOLD,
    /** Centred title, tiny subtitle underneath (iOS). */
    CENTERED,
    /** Oversized headline pushed high with wide side margins (One UI). */
    LARGE_COMFORT,
    /** Uppercase tracked headline with a rule beneath (EMUI/XOS). */
    TAB_UPPER
}

/** The selected-state marker drawn on a dock item. */
enum class NavIndicator {
    PILL,
    UNDERLINE,
    DOT,
    NONE
}

/** How the Vault Composition chart is cut. Each brand ships its own chart idiom. */
enum class PieForm {
    /** Solid wedges meeting at the centre — the flat MIUI / Fluent pie. */
    WEDGE,
    /** One stroked ring, arcs separated by gaps — iOS, One UI, Funtouch. */
    RING,
    /** A band per category, each on its own concentric radius — ColorOS / EMUI. */
    STACKED_RING,
    /** The same dial tipped toward the viewer: a squashed top face standing on a shaded wall. */
    WEDGE_3D,
    /** No dial at all — one horizontal rail of proportional segments with hard gaps between them. */
    SEGMENTED,
    /** A horizontal bar chart: one track and one proportional fill per live category. */
    BARS
}

/** The shape of the legend key beside the chart. */
enum class PieLegend {
    DOT,
    SQUARE,
    DIAMOND,
    BAR,
    RING
}

data class VaultPalette(
    val id: String,
    val name: String,
    val tagline: String,
    val inspiredBy: String,
    val isLight: Boolean = false,
    val abyssDark: Color,
    val abyssSurface: Color,
    val abyssElevated: Color,
    val abyssGlass: Color,
    val cyan: Color,
    val amber: Color,
    val indigo: Color,
    val mint: Color,
    val coral: Color,
    val lavender: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val glassBorder: Color,
    val glassHighlight: Color,
    val dangerDim: Color,
    val design: ThemeDesign = ThemeDesign.LIQUID_GLASS,
    val backdrop: VaultBackdrop = VaultBackdrop.AURORA_MESH,
    val layout: VaultLayout = VaultLayout.CLASSIC,
    val iconStyle: IconStyle = IconStyle.ROUNDED,
    val cardCorner: Dp = 22.dp,
    val buttonCorner: Dp = 18.dp,
    val inputCorner: Dp = 16.dp,
    val chipCorner: Dp = 8.dp,
    val navCorner: Dp = 26.dp,
    val cardBorderWidth: Dp = 1.dp,
    val cardFillAlpha: Float = 0.72f,
    val cardGradient: Boolean = true,
    val cardHighlight: Boolean = true,
    val cardShadow: Dp = 0.dp,
    val glow: Boolean = true,
    val meshIntensity: Float = 0.7f,
    val gradientButtons: Boolean = true,
    val hardOutline: Boolean = false,
    val embossed: Boolean = false,
    val navFloating: Boolean = true,
    val uppercaseLabels: Boolean = false,
    val monoTags: Boolean = false,
    /**
     * Icon-plate radius. One shared value for every theme — the generated board draws
     * the same squircle in every palette, so the Kotlin tile must not drift per
     * theme either. No palette may override this; see ThemeTokensTest.
     *
     * The number comes from the board itself: the vectors bake a corner of 60 units in
     * a 256-unit plate (23.4%), and the default tile is 38.dp, so 38 * 60/256 ~= 8.9.dp.
     * A fixed dp cannot track a growing tile, so this is the board's own radius at the
     * size the tiles actually ship at — every call site between 30.dp and 48.dp stays
     * within a hair of the vector plate's silhouette.
     */
    val iconTileCorner: Dp = 9.dp,
    val pressDepth: Dp = 0.dp,
    val backdropBlur: Dp = 0.dp,
    val sheen: Boolean = false,
    val dock: DockStyle = DockStyle.SOFT_FLOATING,
    val header: HeaderStyle = HeaderStyle.INLINE_BOLD,
    val navIndicator: NavIndicator = NavIndicator.PILL,
    val navLabels: Boolean = true,
    /** Alpha of the dock fill; below ~0.85 the wallpaper reads through. */
    val navFrostAlpha: Float = 0.97f,
    val navHeight: Dp = 62.dp,
    val navIconSize: Dp = 21.dp,
    val navLabelSize: TextUnit = 10.sp,
    val screenGutter: Dp = 18.dp,
    /**
     * Home board geometry. These four are the same for every theme on purpose: the
     * icons and their layout have to read identically whichever theme is picked, so
     * only the plate colours move.
     */
    val gridGutter: Dp = 8.dp,
    val moduleTilePadH: Dp = 6.dp,
    val moduleTilePadV: Dp = 11.dp,
    val moduleIconSize: Dp = 34.dp,
    val moduleLabelSize: TextUnit = 10.sp,
    /** How this brand cuts its Vault Composition chart. */
    val pieForm: PieForm = PieForm.RING,
    /** Empty degrees between two arcs; wedge charts use a separator stroke instead. */
    val pieGapDegrees: Float = 3.5f,
    val pieRoundCaps: Boolean = true,
    /** Radial wash across each slice instead of flat fill. */
    val pieGradient: Boolean = false,
    /** Hairline between wedges, in the card surface colour. */
    val pieSeparator: Dp = 0.dp,
    val pieTrackAlpha: Float = 0.55f,
    /** 0 = solid pie, higher = thinner ring. Only read by the ring forms. */
    val pieInnerRatio: Float = 0.62f,
    val pieLegend: PieLegend = PieLegend.DOT,
    /** Selected slice steps outward, the iOS/MIUI affordance. */
    val pieSelectedLift: Boolean = false
) {
    val preview: List<Color>
        get() = listOf(cyan, indigo, mint, amber, lavender, coral)

    val cardShape: RoundedCornerShape get() = RoundedCornerShape(cardCorner)
    val buttonShape: RoundedCornerShape get() = RoundedCornerShape(buttonCorner)
    val inputShape: RoundedCornerShape get() = RoundedCornerShape(inputCorner)
    val chipShape: RoundedCornerShape get() = RoundedCornerShape(chipCorner)
    val navShape: RoundedCornerShape get() = RoundedCornerShape(navCorner)
    val iconShape: RoundedCornerShape get() = RoundedCornerShape(iconTileCorner)
    val outlineColor: Color
        get() = if (hardOutline) textPrimary.copy(alpha = 0.92f) else glassBorder

    /**
     * Overlay ink for dividers, chips and inset panels that sit on a card. Light
     * themes need a darkening tint and dark themes a lifting one, otherwise the
     * same hardcoded white reads as a washed-out ghost box on every light palette.
     */
    val surfaceOverlay: Color
        get() = if (isLight) textPrimary else Color.White

    /** Shadow ink for embossing and vignettes, instead of a flat black. */
    val surfaceShade: Color
        get() = if (isLight) textPrimary else abyssDark

    /**
     * The unfilled ring behind a chart. The brand hairline is tinted and already
     * semi-transparent, so stacking [pieTrackAlpha] on it produced a muddy wash that
     * read as dirt on the dark themes; this lifts or darkens the card surface with a
     * single neutral tint instead.
     */
    val pieTrack: Color
        get() = surfaceOverlay.copy(alpha = (pieTrackAlpha * 0.4f).coerceIn(0.05f, 0.22f))
}

object VaultPalettes {
    // The owner's handset runs ColorOS, and Aqua Tint is the one theme whose layout
    // grammar actually matches it, so an unknown or retired id lands there.
    const val DEFAULT_ID = "aqua"
    const val DEFAULT_LIGHT_ID = "solstice"
    const val DEFAULT_DARK_ID = "dark"

    val all: List<VaultPalette> = listOf(
        // 1 — Solar Pop: warm paper, electric ink blocks, hard outlines, mosaic cells.
        VaultPalette(
            id = "solstice",
            name = "Solar Pop",
            tagline = "Electric red and poster yellow on warm paper, hard outlines, mosaic cells",
            inspiredBy = "Screen-print poster",
            iconStyle = IconStyle.FILLED,
            isLight = true,
            // The poster look lives in the hard outlines and the mosaic board; the design token
            // stays NEUTRAL so the icon plates remain tints instead of solid blocks.
            design = ThemeDesign.NEUTRAL,
            backdrop = VaultBackdrop.HARD_GRID,
            layout = VaultLayout.MOSAIC,
            abyssDark = Color(0xFFFFF6DF),
            abyssSurface = Color(0xFFFFFFFF),
            abyssElevated = Color(0xFFFFE9B8),
            abyssGlass = Color(0xF2FFFFFF),
            cyan = Color(0xFFC1121F),
            amber = Color(0xFFFFB000),
            indigo = Color(0xFF1D4ED8),
            mint = Color(0xFF00B84C),
            coral = Color(0xFFFF6B6B),
            lavender = Color(0xFFFFD400),
            textPrimary = Color(0xFF150E00),
            textSecondary = Color(0xFF4A3A18),
            textMuted = Color(0xFF6E5D34),
            glassBorder = Color(0xE6150E00),
            glassHighlight = Color(0x0A000000),
            dangerDim = Color(0xFFFFD8D8),
            cardCorner = 10.dp,
            buttonCorner = 8.dp,
            inputCorner = 6.dp,
            chipCorner = 4.dp,
            navCorner = 4.dp,
            cardBorderWidth = 2.dp,
            cardFillAlpha = 1f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 0.dp,
            glow = false,
            meshIntensity = 0.3f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = false,
            uppercaseLabels = true,
            monoTags = true,
            pressDepth = 3.dp,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.FLAT_PLATE,
            header = HeaderStyle.INLINE_BOLD,
            navIndicator = NavIndicator.UNDERLINE,
            navFrostAlpha = 1f,
            navHeight = 68.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.WEDGE_3D,
            pieGapDegrees = 0f,
            pieRoundCaps = false,
            pieGradient = false,
            pieSeparator = 2.dp,
            pieTrackAlpha = 0.28f,
            pieInnerRatio = 0.88f,
            pieLegend = PieLegend.SQUARE,
            pieSelectedLift = false
        ),
        // 2 — Samsung One UI: oversized headline, wide gutters, tall comfort dock.
        VaultPalette(
            id = "oneui",
            name = "Comfort Panel",
            tagline = "One UI-style large headers, roomy margins, tall labelled dock",
            inspiredBy = "Samsung One UI",
            iconStyle = IconStyle.OUTLINED,
            isLight = true,
            design = ThemeDesign.GENERATIVE,
            backdrop = VaultBackdrop.TEXTURED,
            layout = VaultLayout.ADAPTIVE,
            abyssDark = Color(0xFFF6F7FB),
            abyssSurface = Color(0xFFFFFFFF),
            abyssElevated = Color(0xFFE9ECF5),
            abyssGlass = Color(0xE6FFFFFF),
            cyan = Color(0xFF2563EB),
            amber = Color(0xFFE88B00),
            indigo = Color(0xFF1D4ED8),
            mint = Color(0xFF14B87A),
            coral = Color(0xFFE64545),
            lavender = Color(0xFFFFD400),
            textPrimary = Color(0xFF0D1017),
            textSecondary = Color(0xFF4B5261),
            textMuted = Color(0xFF868D9C),
            glassBorder = Color(0x140D1017),
            glassHighlight = Color(0x14FFFFFF),
            dangerDim = Color(0xFFFDE3E3),
            cardCorner = 26.dp,
            buttonCorner = 26.dp,
            inputCorner = 20.dp,
            chipCorner = 16.dp,
            navCorner = 30.dp,
            cardBorderWidth = 0.dp,
            cardFillAlpha = 0.98f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 6.dp,
            glow = false,
            gradientButtons = false,
            navFloating = true,
            dock = DockStyle.COMFORT_PANEL,
            header = HeaderStyle.LARGE_COMFORT,
            navIndicator = NavIndicator.UNDERLINE,
            navHeight = 76.dp,
            navIconSize = 24.dp,
            navLabelSize = 11.sp,
            navFrostAlpha = 0.99f,
            pieForm = PieForm.RING,
            pieGapDegrees = 9f,
            pieRoundCaps = false,
            pieTrackAlpha = 0.22f,
            pieInnerRatio = 0.78f,
            pieLegend = PieLegend.BAR
        ),
        // 3 — ColorOS / Oppo: deep ink panes, glossy accent layers, wide radii.
        VaultPalette(
            id = "aqua",
            name = "Aqua Tint",
            tagline = "ColorOS-style accent layers over sleek glass panes",
            inspiredBy = "Oppo ColorOS",
            iconStyle = IconStyle.OUTLINED,
            design = ThemeDesign.LIQUID_GLASS,
            backdrop = VaultBackdrop.AURORA_MESH,
            layout = VaultLayout.COMPACT,
            abyssDark = Color(0xFF04101C),
            abyssSurface = Color(0xFF0A1B2C),
            abyssElevated = Color(0xFF12293F),
            abyssGlass = Color(0x99123049),
            cyan = Color(0xFF38BDF8),
            amber = Color(0xFFFFB44D),
            indigo = Color(0xFF6C8CFF),
            mint = Color(0xFF5EE6A0),
            coral = Color(0xFFFF6B6B),
            lavender = Color(0xFFFFD400),
            textPrimary = Color(0xFFF7FCFF),
            textSecondary = Color(0xFFC3DCF0),
            textMuted = Color(0xFF91B2CC),
            glassBorder = Color(0x6633E8C8),
            glassHighlight = Color(0x3DFFFFFF),
            dangerDim = Color(0xFF331414),
            cardCorner = 32.dp,
            buttonCorner = 26.dp,
            inputCorner = 20.dp,
            chipCorner = 16.dp,
            navCorner = 32.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.58f,
            cardShadow = 16.dp,
            meshIntensity = 0.95f,
            backdropBlur = 34.dp,
            sheen = true,
            dock = DockStyle.PILL_FROSTED,
            header = HeaderStyle.CENTERED,
            navIndicator = NavIndicator.PILL,
            navHeight = 64.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            navFrostAlpha = 0.74f,
            pieForm = PieForm.STACKED_RING,
            pieGapDegrees = 2f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.35f,
            pieInnerRatio = 0.50f,
            pieLegend = PieLegend.RING
        ),
        // 4 — Neon Lime: daylight cyberpunk, lime and cyan on white glass, sharp plates.
        VaultPalette(
            id = "lime",
            name = "Neon Lime",
            tagline = "Daylight lime and cyan neon on white glass with sharp plates",
            inspiredBy = "Arcade daylight",
            isLight = true,
            design = ThemeDesign.CYBERPUNK,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.CLASSIC,
            iconStyle = IconStyle.SHARP,
            abyssDark = Color(0xFFF3FFF0),
            abyssSurface = Color(0xFFFFFFFF),
            abyssElevated = Color(0xFFE3FFD6),
            abyssGlass = Color(0xE6FFFFFF),
            cyan = Color(0xFF2BD46A),
            amber = Color(0xFFFFB000),
            indigo = Color(0xFF1D4ED8),
            mint = Color(0xFF00C853),
            coral = Color(0xFFD2222F),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFF07130A),
            textSecondary = Color(0xFF2E4A34),
            textMuted = Color(0xFF52705A),
            glassBorder = Color(0x332BD46A),
            glassHighlight = Color(0x30FFFFFF),
            dangerDim = Color(0xFFFFD9D9),
            cardCorner = 4.5.dp,
            buttonCorner = 3.5.dp,
            inputCorner = 3.dp,
            chipCorner = 2.5.dp,
            navCorner = 6.dp,
            cardBorderWidth = 1.5.dp,
            cardFillAlpha = 0.92f,
            cardGradient = true,
            cardHighlight = true,
            cardShadow = 4.dp,
            glow = true,
            meshIntensity = 0.55f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = true,
            uppercaseLabels = true,
            monoTags = true,
            backdropBlur = 8.dp,
            sheen = false,
            dock = DockStyle.SOFT_FLOATING,
            header = HeaderStyle.TAB_UPPER,
            navIndicator = NavIndicator.DOT,
            navFrostAlpha = 0.92f,
            navHeight = 64.dp,
            navIconSize = 21.dp,
            navLabelSize = 9.sp,
            pieForm = PieForm.SEGMENTED,
            pieGapDegrees = 1.5f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.25f,
            pieInnerRatio = 0.55f,
            pieLegend = PieLegend.RING,
            pieSelectedLift = true
        ),
        // 5 — Midnight Pop: near-black glass with electric accents, high contrast.
        VaultPalette(
            id = "dark",
            name = "Midnight Pop",
            tagline = "Near-black glass with electric accents and high-contrast text",
            inspiredBy = "Night arcade",
            design = ThemeDesign.GENERATIVE,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.LEDGER,
            iconStyle = IconStyle.OUTLINED,
            abyssDark = Color(0xFF0A0A12),
            abyssSurface = Color(0xFF12121C),
            abyssElevated = Color(0xFF1F1F2E),
            abyssGlass = Color(0xCC171724),
            cyan = Color(0xFFFFD400),
            amber = Color(0xFFFFC400),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF00FF9D),
            coral = Color(0xFFFF5C5C),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFFF7F5FF),
            textSecondary = Color(0xFFD2DCEC),
            textMuted = Color(0xFFA4AABE),
            glassBorder = Color(0x24FFFFFF),
            glassHighlight = Color(0x14FFFFFF),
            dangerDim = Color(0xFF3E2E2C),
            cardCorner = 12.dp,
            buttonCorner = 24.dp,
            inputCorner = 12.dp,
            chipCorner = 8.dp,
            navCorner = 0.dp,
            cardBorderWidth = 0.dp,
            cardFillAlpha = 1f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 3.dp,
            glow = false,
            meshIntensity = 0.25f,
            gradientButtons = false,
            navFloating = false,
            dock = DockStyle.MINIMAL_BAR,
            header = HeaderStyle.INLINE_BOLD,
            navIndicator = NavIndicator.PILL,
            navHeight = 74.dp,
            navIconSize = 24.dp,
            navLabelSize = 12.sp,
            navFrostAlpha = 1f,
            pieForm = PieForm.BARS,
            pieGapDegrees = 2f,
            pieRoundCaps = false,
            pieTrackAlpha = 0.24f,
            pieInnerRatio = 0.60f,
            pieLegend = PieLegend.DOT
        ),
        // 6 — Obsidian Noir: graphite editorial dark, desaturated champagne gold,
        // minimal bar dock and uppercase tracked headers. Calm, no glow.
        VaultPalette(
            id = "noir",
            name = "Obsidian Noir",
            tagline = "Graphite editorial dark with champagne gold and tracked caps headers",
            inspiredBy = "Print editorial",
            iconStyle = IconStyle.OUTLINED,
            design = ThemeDesign.AGENTIC,
            backdrop = VaultBackdrop.CALM,
            layout = VaultLayout.DENSE,
            abyssDark = Color(0xFF121418),
            abyssSurface = Color(0xFF1A1D22),
            abyssElevated = Color(0xFF242830),
            abyssGlass = Color(0xCC1E2228),
            cyan = Color(0xFFFFC94D),
            amber = Color(0xFFFF9F1C),
            indigo = Color(0xFF6EA8FF),
            mint = Color(0xFF7BE495),
            coral = Color(0xFFFF6B5E),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFFFBF8EF),
            textSecondary = Color(0xFFCFC9B8),
            textMuted = Color(0xFF9C9688),
            glassBorder = Color(0x3D8F7A4A),
            glassHighlight = Color(0x1FFFFFFF),
            dangerDim = Color(0xFF38221D),
            cardCorner = 16.dp,
            buttonCorner = 12.dp,
            inputCorner = 12.dp,
            chipCorner = 6.dp,
            navCorner = 0.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.94f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 8.dp,
            glow = false,
            meshIntensity = 0.3f,
            gradientButtons = false,
            navFloating = false,
            uppercaseLabels = true,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.MINIMAL_BAR,
            header = HeaderStyle.TAB_UPPER,
            navIndicator = NavIndicator.UNDERLINE,
            navFrostAlpha = 0.98f,
            navHeight = 58.dp,
            navIconSize = 20.dp,
            navLabelSize = 9.sp,
            pieForm = PieForm.WEDGE,
            pieGapDegrees = 0f,
            pieRoundCaps = false,
            pieGradient = false,
            pieSeparator = 1.dp,
            pieTrackAlpha = 0.2f,
            pieInnerRatio = 0.9f,
            pieLegend = PieLegend.SQUARE,
            pieSelectedLift = false
        ),
        // 7 — Mint Ledger: airy light green/teal, bento tiles, soft floating dock,
        // large comfort headers, zero glow.
        VaultPalette(
            id = "mint",
            name = "Mint Ledger",
            tagline = "Airy green/teal light theme with soft bento tiles and comfort headers",
            inspiredBy = "Ledger paper",
            isLight = true,
            iconStyle = IconStyle.ROUNDED,
            design = ThemeDesign.BENTO,
            backdrop = VaultBackdrop.PULSE_MESH,
            layout = VaultLayout.DUO,
            abyssDark = Color(0xFFE8F3EC),
            abyssSurface = Color(0xFFF6FBF7),
            abyssElevated = Color(0xFFDDEBE2),
            abyssGlass = Color(0xA6FFFFFF),
            cyan = Color(0xFF00C853),
            amber = Color(0xFFE3A23C),
            indigo = Color(0xFF4B6BCB),
            mint = Color(0xFF2FA36B),
            coral = Color(0xFFD6604A),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFF0F2A22),
            textSecondary = Color(0xFF3E5C50),
            textMuted = Color(0xFF6E8B7E),
            glassBorder = Color(0x3300C853),
            glassHighlight = Color(0x4DFFFFFF),
            dangerDim = Color(0xFFFBE3DE),
            cardCorner = 24.dp,
            buttonCorner = 20.dp,
            inputCorner = 16.dp,
            chipCorner = 12.dp,
            navCorner = 28.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.85f,
            cardGradient = false,
            cardHighlight = true,
            cardShadow = 6.dp,
            glow = false,
            meshIntensity = 0.45f,
            gradientButtons = true,
            navFloating = true,
            backdropBlur = 18.dp,
            sheen = false,
            dock = DockStyle.SOFT_FLOATING,
            header = HeaderStyle.LARGE_COMFORT,
            navIndicator = NavIndicator.PILL,
            navFrostAlpha = 0.9f,
            navHeight = 70.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.RING,
            pieGapDegrees = 6f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.3f,
            pieInnerRatio = 0.72f,
            pieLegend = PieLegend.DOT,
            pieSelectedLift = false
        ),
        // 8 — Sunset Dusk: warm coral/amber mesh on umber glass, frosted pill dock,
        // gradient cards with a top sheen.
        VaultPalette(
            id = "sunset",
            name = "Sunset Dusk",
            tagline = "Warm coral dusk mesh with sheened gradient cards and a frosted pill dock",
            inspiredBy = "Golden hour",
            iconStyle = IconStyle.ROUNDED,
            design = ThemeDesign.GENERATIVE,
            backdrop = VaultBackdrop.AURORA_MESH,
            layout = VaultLayout.GALLERY,
            abyssDark = Color(0xFF131313),
            abyssSurface = Color(0xFF2A1A16),
            abyssElevated = Color(0xFF3A241C),
            abyssGlass = Color(0x993A241C),
            cyan = Color(0xFFFF7A7A),
            amber = Color(0xFFFFB35C),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF5BCF9B),
            coral = Color(0xFFD2222F),
            lavender = Color(0xFFFFD400),
            textPrimary = Color(0xFFFFEDE2),
            textSecondary = Color(0xFFD6AFA0),
            textMuted = Color(0xFF9E7E73),
            glassBorder = Color(0x40FF7A7A),
            glassHighlight = Color(0x2FFFFF9A),
            dangerDim = Color(0xFF3B1414),
            cardCorner = 28.dp,
            buttonCorner = 22.dp,
            inputCorner = 18.dp,
            chipCorner = 14.dp,
            navCorner = 30.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.66f,
            cardGradient = true,
            cardHighlight = true,
            cardShadow = 10.dp,
            glow = false,
            meshIntensity = 1f,
            gradientButtons = true,
            navFloating = true,
            backdropBlur = 26.dp,
            sheen = true,
            dock = DockStyle.PILL_FROSTED,
            header = HeaderStyle.INLINE_BOLD,
            navIndicator = NavIndicator.PILL,
            navFrostAlpha = 0.62f,
            navHeight = 64.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.STACKED_RING,
            pieGapDegrees = 0f,
            pieRoundCaps = false,
            pieGradient = true,
            pieSeparator = 1.dp,
            pieTrackAlpha = 0.35f,
            pieInnerRatio = 0.85f,
            pieLegend = PieLegend.DIAMOND,
            pieSelectedLift = true
        ),
        // 9 — Arctic Frost: near-white ice blue, heavy blur on every frosted pane,
        // centred titles, translucent capsule dock.
        VaultPalette(
            id = "arctic",
            name = "Arctic Frost",
            tagline = "Icy near-white light theme with deep frosted blur and centred titles",
            inspiredBy = "Polar glass",
            isLight = true,
            iconStyle = IconStyle.ROUNDED,
            design = ThemeDesign.LIQUID_GLASS,
            backdrop = VaultBackdrop.PULSE_MESH,
            layout = VaultLayout.TRIAD,
            abyssDark = Color(0xFFEDF2F8),
            abyssSurface = Color(0xFFF8FBFE),
            abyssElevated = Color(0xFFDCE7F2),
            abyssGlass = Color(0xB3FFFFFF),
            cyan = Color(0xFF1D4ED8),
            amber = Color(0xFFD9A648),
            indigo = Color(0xFF5B7FD4),
            mint = Color(0xFF35B87F),
            coral = Color(0xFFE4574C),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFF0C1B2A),
            textSecondary = Color(0xFF3D556E),
            textMuted = Color(0xFF6E86A0),
            glassBorder = Color(0x260C1B2A),
            glassHighlight = Color(0x59FFFFFF),
            dangerDim = Color(0xFFFFE1E1),
            cardCorner = 32.dp,
            buttonCorner = 26.dp,
            inputCorner = 22.dp,
            chipCorner = 18.dp,
            navCorner = 36.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.72f,
            cardGradient = true,
            cardHighlight = true,
            cardShadow = 12.dp,
            glow = false,
            meshIntensity = 0.55f,
            gradientButtons = true,
            navFloating = true,
            backdropBlur = 48.dp,
            sheen = true,
            dock = DockStyle.PILL_FROSTED,
            header = HeaderStyle.CENTERED,
            navIndicator = NavIndicator.PILL,
            navFrostAlpha = 0.55f,
            navHeight = 68.dp,
            navIconSize = 23.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.WEDGE,
            pieGapDegrees = 5f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.28f,
            pieInnerRatio = 0.74f,
            pieLegend = PieLegend.RING,
            pieSelectedLift = true
        ),
        // 10 — Volt Aura: cyberpunk lime/cyan neon on near-black, hard outlines,
        // monospace tags, wedge chart with separators.
        VaultPalette(
            id = "voltra",
            name = "Volt Aura",
            tagline = "Neon lime and cyan on near-black with hard outlines and glow",
            inspiredBy = "Arcade night",
            iconStyle = IconStyle.SHARP,
            design = ThemeDesign.CYBERPUNK,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.SPLIT,
            abyssDark = Color(0xFF05080A),
            abyssSurface = Color(0xFF0D1316),
            abyssElevated = Color(0xFF17242B),
            abyssGlass = Color(0x99101A1F),
            cyan = Color(0xFF00E676),
            amber = Color(0xFFFFD400),
            indigo = Color(0xFF23E3FF),
            mint = Color(0xFF38F2A0),
            coral = Color(0xFFFF5C5C),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFFECFFF4),
            textSecondary = Color(0xFF9FC4B8),
            textMuted = Color(0xFF62827A),
            glassBorder = Color(0x4000E676),
            glassHighlight = Color(0x3323E3FF),
            dangerDim = Color(0xFF2A1414),
            cardCorner = 6.dp,
            buttonCorner = 4.dp,
            inputCorner = 4.dp,
            chipCorner = 2.dp,
            navCorner = 10.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.8f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 0.dp,
            glow = true,
            meshIntensity = 1f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = true,
            uppercaseLabels = true,
            monoTags = true,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.SOFT_FLOATING,
            header = HeaderStyle.TAB_UPPER,
            navIndicator = NavIndicator.DOT,
            navFrostAlpha = 0.9f,
            navHeight = 64.dp,
            navIconSize = 20.dp,
            navLabelSize = 9.sp,
            pieForm = PieForm.SEGMENTED,
            pieGapDegrees = 0f,
            pieRoundCaps = false,
            pieGradient = false,
            pieSeparator = 2.dp,
            pieTrackAlpha = 0.4f,
            pieInnerRatio = 0.9f,
            pieLegend = PieLegend.SQUARE,
            pieSelectedLift = false
        ),
        // 11 — Neon Cyan: wet-electric cyan over blue-black glass, hard outlined plates,
        // intent rails over a quiet icon grid.
        VaultPalette(
            id = "neon_cyan",
            name = "Neon Cyan",
            tagline = "Electric cyan on blue-black glass with hard outlines and intent rails",
            inspiredBy = "Neon terminal",
            iconStyle = IconStyle.SHARP,
            design = ThemeDesign.CYBERPUNK,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.AGENTIC,
            abyssDark = Color(0xFF04070C),
            abyssSurface = Color(0xFF0A1119),
            abyssElevated = Color(0xFF122030),
            abyssGlass = Color(0x990E1A26),
            cyan = Color(0xFF5BB8F5),
            amber = Color(0xFFFFD54D),
            indigo = Color(0xFF0B6BFF),
            mint = Color(0xFF4DFFB0),
            coral = Color(0xFFFF6B6B),
            lavender = Color(0xFFFFD400),
            textPrimary = Color(0xFFEFFDFF),
            textSecondary = Color(0xFFB4D8E6),
            textMuted = Color(0xFF7E9FAE),
            glassBorder = Color(0x4D5BB8F5),
            glassHighlight = Color(0x26FFFFFF),
            dangerDim = Color(0xFF2B1515),
            cardCorner = 8.dp,
            buttonCorner = 6.dp,
            inputCorner = 6.dp,
            chipCorner = 3.dp,
            navCorner = 8.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.78f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 0.dp,
            glow = true,
            meshIntensity = 1f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = true,
            uppercaseLabels = true,
            monoTags = true,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.SOFT_FLOATING,
            header = HeaderStyle.TAB_UPPER,
            navIndicator = NavIndicator.DOT,
            navFrostAlpha = 0.9f,
            navHeight = 64.dp,
            navIconSize = 21.dp,
            navLabelSize = 9.sp,
            pieForm = PieForm.BARS,
            pieGapDegrees = 0f,
            pieRoundCaps = false,
            pieGradient = false,
            pieSeparator = 2.dp,
            pieTrackAlpha = 0.36f,
            pieInnerRatio = 0.9f,
            pieLegend = PieLegend.BAR,
            pieSelectedLift = false
        ),
        // 12 — Royal Blue: deep navy premium dark with gold hairlines,
        // frosted capsule dock and gradient ring chart. Pairs with the crypto
        // panel's exchange mode.
        VaultPalette(
            id = "royal",
            name = "Royal Blue",
            tagline = "Deep navy premium dark with gold hairlines and a frosted capsule dock",
            inspiredBy = "Palace vault",
            iconStyle = IconStyle.OUTLINED,
            design = ThemeDesign.BENTO,
            backdrop = VaultBackdrop.AURORA_MESH,
            layout = VaultLayout.STRIP,
            abyssDark = Color(0xFF060B18),
            abyssSurface = Color(0xFF0C1428),
            abyssElevated = Color(0xFF16223F),
            abyssGlass = Color(0x99122040),
            cyan = Color(0xFF1E40AF),
            amber = Color(0xFFF5C518),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF3ED6A4),
            coral = Color(0xFFFF6B6B),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFFEEF4FF),
            textSecondary = Color(0xFFB4C4E0),
            textMuted = Color(0xFF7E8DA8),
            glassBorder = Color(0x4DF5C518),
            glassHighlight = Color(0x24F5C518),
            dangerDim = Color(0xFF3A1212),
            cardCorner = 24.dp,
            buttonCorner = 18.dp,
            inputCorner = 16.dp,
            chipCorner = 12.dp,
            navCorner = 30.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.8f,
            cardGradient = true,
            cardHighlight = true,
            cardShadow = 14.dp,
            glow = false,
            meshIntensity = 0.6f,
            gradientButtons = true,
            navFloating = true,
            backdropBlur = 20.dp,
            sheen = false,
            dock = DockStyle.PILL_FROSTED,
            header = HeaderStyle.CENTERED,
            navIndicator = NavIndicator.PILL,
            navFrostAlpha = 0.66f,
            navHeight = 66.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.RING,
            pieGapDegrees = 4f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.32f,
            pieInnerRatio = 0.68f,
            pieLegend = PieLegend.BAR,
            pieSelectedLift = true
        ),
        // 13 — Signal Red: hot red over ember-black glass, hard outlined plates,
        // an opening rail above three equal columns, frosted capsule dock.
        VaultPalette(
            id = "neon_magenta",
            name = "Signal Red",
            tagline = "Hot red on ember-black glass with hard outlines and a capsule dock",
            inspiredBy = "Alert skyline",
            iconStyle = IconStyle.SHARP,
            design = ThemeDesign.CYBERPUNK,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.COLUMN,
            abyssDark = Color(0xFF0A0A0A),
            abyssSurface = Color(0xFF121212),
            abyssElevated = Color(0xFF1D1D1D),
            abyssGlass = Color(0x99171717),
            cyan = Color(0xFFD2222F),
            amber = Color(0xFFFFC24D),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF35F5C0),
            coral = Color(0xFFFF6B6B),
            lavender = Color(0xFF38BDF8),
            textPrimary = Color(0xFFFFF2F1),
            textSecondary = Color(0xFFE8C3BF),
            textMuted = Color(0xFFAE8B8B),
            glassBorder = Color(0x4DD2222F),
            glassHighlight = Color(0x26FFFFFF),
            dangerDim = Color(0xFF3E1010),
            cardCorner = 10.dp,
            buttonCorner = 8.dp,
            inputCorner = 8.dp,
            chipCorner = 4.dp,
            navCorner = 26.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.72f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 0.dp,
            glow = true,
            meshIntensity = 1f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = true,
            uppercaseLabels = true,
            monoTags = true,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.PILL_FROSTED,
            header = HeaderStyle.CENTERED,
            navIndicator = NavIndicator.PILL,
            navFrostAlpha = 0.7f,
            navHeight = 66.dp,
            navIconSize = 21.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.WEDGE_3D,
            pieGapDegrees = 1f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.32f,
            pieInnerRatio = 0.52f,
            pieLegend = PieLegend.BAR,
            pieSelectedLift = true
        ),
        // 14 — Glacier Blue: cool ice-blue clay plates, rounded everything,
        // floating dock with dot indicators.
        VaultPalette(
            id = "sakura",
            name = "Glacier Blue",
            tagline = "Cool glacier-blue clay plates, rounded everything, floating dock with dots",
            inspiredBy = "Alpine ice",
            isLight = true,
            iconStyle = IconStyle.ROUNDED,
            design = ThemeDesign.CLAYMORPHISM,
            backdrop = VaultBackdrop.PULSE_MESH,
            layout = VaultLayout.BENTO,
            abyssDark = Color(0xFFEDF4FA),
            abyssSurface = Color(0xFFFBFDFF),
            abyssElevated = Color(0xFFDCE9F4),
            abyssGlass = Color(0xE6FFFFFF),
            cyan = Color(0xFF7DD3FC),
            amber = Color(0xFFE5A75F),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF58A574),
            coral = Color(0xFFD95555),
            lavender = Color(0xFF5BB8F5),
            textPrimary = Color(0xFF14283C),
            textSecondary = Color(0xFF3D5A6B),
            textMuted = Color(0xFF6C8698),
            glassBorder = Color(0x332563EB),
            glassHighlight = Color(0x4DFFFFFF),
            dangerDim = Color(0xFFFFD9D9),
            cardCorner = 30.dp,
            buttonCorner = 26.dp,
            inputCorner = 22.dp,
            chipCorner = 22.dp,
            navCorner = 32.dp,
            cardBorderWidth = 0.dp,
            cardFillAlpha = 0.9f,
            cardGradient = false,
            cardHighlight = false,
            cardShadow = 16.dp,
            glow = false,
            meshIntensity = 0.45f,
            gradientButtons = true,
            embossed = true,
            navFloating = true,
            pressDepth = 2.dp,
            backdropBlur = 12.dp,
            sheen = false,
            dock = DockStyle.SOFT_FLOATING,
            header = HeaderStyle.LARGE_COMFORT,
            navIndicator = NavIndicator.DOT,
            navFrostAlpha = 0.88f,
            navHeight = 72.dp,
            navIconSize = 22.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.STACKED_RING,
            pieGapDegrees = 3f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.25f,
            pieInnerRatio = 0.5f,
            pieLegend = PieLegend.DOT,
            pieSelectedLift = false
        ),
        // 15 — Neon Plasma: electric cyan with hot-red counterlight over ink-black glass,
        // hard outlined plates, the thickest floating dock and a gradient ring chart.
        VaultPalette(
            id = "neon_plasma",
            name = "Neon Plasma",
            tagline = "Electric cyan and hot-red counterlight on ink-black glass with thick floats",
            inspiredBy = "Plasma arc",
            iconStyle = IconStyle.SHARP,
            design = ThemeDesign.CYBERPUNK,
            backdrop = VaultBackdrop.NEON_MESH,
            layout = VaultLayout.GENERATIVE,
            abyssDark = Color(0xFF070707),
            abyssSurface = Color(0xFF101010),
            abyssElevated = Color(0xFF1A1A1A),
            abyssGlass = Color(0x99151515),
            cyan = Color(0xFFFF6B6B),
            amber = Color(0xFFFFC94D),
            indigo = Color(0xFF2563EB),
            mint = Color(0xFF38F5C8),
            coral = Color(0xFFD2222F),
            lavender = Color(0xFF62E8FF),
            textPrimary = Color(0xFFF6F4F6),
            textSecondary = Color(0xFFC9C4CC),
            textMuted = Color(0xFF8E8F98),
            glassBorder = Color(0x4DFF6B6B),
            glassHighlight = Color(0x24FF6B6B),
            dangerDim = Color(0xFF381414),
            cardCorner = 30.dp,
            buttonCorner = 24.dp,
            inputCorner = 18.dp,
            chipCorner = 14.dp,
            navCorner = 30.dp,
            cardBorderWidth = 1.dp,
            cardFillAlpha = 0.74f,
            cardGradient = true,
            cardHighlight = true,
            cardShadow = 12.dp,
            glow = true,
            meshIntensity = 0.95f,
            gradientButtons = true,
            hardOutline = true,
            navFloating = true,
            uppercaseLabels = true,
            monoTags = true,
            backdropBlur = 0.dp,
            sheen = false,
            dock = DockStyle.COMFORT_PANEL,
            header = HeaderStyle.LARGE_COMFORT,
            navIndicator = NavIndicator.UNDERLINE,
            navFrostAlpha = 0.85f,
            navHeight = 72.dp,
            navIconSize = 23.dp,
            navLabelSize = 10.sp,
            pieForm = PieForm.BARS,
            pieGapDegrees = 5f,
            pieRoundCaps = true,
            pieGradient = true,
            pieTrackAlpha = 0.3f,
            pieInnerRatio = 0.66f,
            pieLegend = PieLegend.DIAMOND,
            pieSelectedLift = true
        )
    )

    /**
     * Retired theme ids mapped onto the closest surviving theme. A theme id lives in
     * DataStore across upgrades, so anything still pointing at a deleted palette would
     * silently fall through to the default; every id this app ever shipped has to land
     * here.
     */
    private val legacyAliases = mapOf(
        // Retired squircle and brand ids land on Solar Pop, the closest vivid light board.
        "ios" to "solstice",
        "ios_glass" to "solstice",
        "apple" to "solstice",
        "iphone" to "solstice",
        "frosted" to "solstice",
        "generative" to "solstice",
        "hyper" to "solstice",
        "hyper_shell" to "solstice",
        "hyperos" to "solstice",
        "miui" to "solstice",
        "xiaomi" to "solstice",
        "clay" to "solstice",
        "claymorphism_3d" to "solstice",
        "funtouch" to "solstice",
        "vivo" to "solstice",
        // Samsung.
        "one_ui" to "oneui",
        "samsung" to "oneui",
        "comfort" to "oneui",
        // ColorOS/Oppo family, plus the old glass-and-aurora ids.
        "liquid" to "aqua",
        "glassmorphism" to "aqua",
        "glass" to "aqua",
        "aurora" to "aqua",
        "coloros" to "aqua",
        "oppo" to "aqua",
        "realme" to "aqua",
        // Plain light surfaces and every retired flat-light id land on Neon Lime.
        "light" to "lime",
        "material_light" to "lime",
        "lumen" to "lime",
        "lumen_white" to "lime",
        "clean" to "lime",
        "clean_light" to "lime",
        "cleanlight" to "lime",
        "porcelain" to "lime",
        "fluent" to "lime",
        "agentic" to "lime",
        "material" to "lime",
        "material_you" to "lime",
        "light_mode" to "lime",
        // Neo-brutalism and the retired grid/slate ids land on the graphite dark, which kept
        // the flat plate dock and the hard vocabulary.
        "slate" to "dark",
        "slate_grid" to "dark",
        "brutalist" to "dark",
        "neo_brutalism" to "dark",
        "neobrutalism" to "dark",
        "bento" to "dark",
        "bento_grid" to "dark",
        "bentogrid" to "dark",
        "skeuomorphic" to "dark",
        "neo_skeuomorphism" to "dark",
        "neoskeuomorphism" to "dark",
        "abyss" to "dark",
        "obsidian" to "dark",
        "obsidian_dark" to "dark",
        "obsidiandark" to "dark",
        "ember" to "dark",
        "emerald" to "dark",
        "volt" to "dark",
        "volt_x" to "dark",
        "xos" to "dark",
        "infinix" to "dark",
        "cyberpunk" to "dark",
        "cyberpunk_glow" to "dark",
        "neon" to "neon_cyan",
        "neon_glow" to "neon_cyan",
        "huawei" to "dark",
        "emui" to "dark",
        "material_dark" to "dark",
        "oled" to "dark",
        "black" to "dark",
        // Retired terracotta clay and graphite panel boards: the nearest surviving grammar.
        "terra" to "sakura",
        "carbon" to "noir"
    )

    fun find(id: String?): VaultPalette {
        val normalized = id?.trim()?.lowercase()
        return all.firstOrNull { it.id == normalized }
            ?: legacyAliases[normalized]?.let { alias -> all.firstOrNull { it.id == alias } }
            ?: all.first { it.id == DEFAULT_ID }
    }
}

private val activePalette = mutableStateOf(VaultPalettes.find(VaultPalettes.DEFAULT_ID))

object VaultPaletteController {
    val active: State<VaultPalette> get() = activePalette
    val current: VaultPalette get() = activePalette.value

    fun apply(id: String?) {
        val next = VaultPalettes.find(id)
        if (next.id != activePalette.value.id) activePalette.value = next
    }

    fun apply(palette: VaultPalette) {
        if (palette.id != activePalette.value.id) activePalette.value = palette
    }
}
